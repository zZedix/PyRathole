from .pyrathole import *

__doc__ = pyrathole.__doc__
if hasattr(pyrathole, "__all__"):
    __all__ = pyrathole.__all__